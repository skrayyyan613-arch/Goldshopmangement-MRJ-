# Gold Shop Manager — Fresh 1.0.0

## Android Studio build
1. Open this folder in Android Studio.
2. Allow Gradle sync and install Android SDK 35 if prompted.
3. Ensure JDK 17 is selected.
4. Run **Build > Make Project**.
5. Run **Build > Build APK(s)**.

## Command line
Run `./gradlew assembleDebug` after Android Studio/Gradle has downloaded the wrapper distribution and Android SDK.

## Note
This package includes Gradle wrapper configuration, but the wrapper JAR cannot be generated in the current environment because a Gradle installation/network download is unavailable here. Android Studio can regenerate it automatically via its Gradle tooling if prompted.
