# Gold Shop Manager — Fresh Build 1.0.0

A clean restart of the Gold Shop Management app. Core modules are included in the Android project:
- Dashboard
- Shop settings / GST details
- Gold rate calculator
- Jewellery inventory with purity, weight, stone weight and making charge
- Customer management
- Sales invoice calculation
- Old-gold purchase calculation
- Ledger with cancellation and stock restoration
- PDF invoice generation/share
- Local Room database

Build target: Android SDK 35, Kotlin 2.0.21, Compose Material 3, Room 2.6.1.

This source package is prepared in this environment; an Android SDK/Gradle toolchain was not available here, so APK compilation could not be executed in this session.

## Phone cloud build

See `PHONE_BUILD_GUIDE.md`. GitHub Actions workflow: `.github/workflows/build-apk.yml`.
