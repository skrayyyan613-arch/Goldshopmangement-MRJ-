plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose"); id("org.jetbrains.kotlin.kapt") }
android { namespace="com.goldshop.manager"; compileSdk=35
 defaultConfig { applicationId="com.goldshop.manager"; minSdk=24; targetSdk=35; versionCode=1; versionName="1.0.0" }
}
dependencies {
 implementation(platform("androidx.compose:compose-bom:2024.12.01"))
 implementation("androidx.activity:activity-compose:1.10.0"); implementation("androidx.core:core-ktx:1.15.0")
 implementation("androidx.compose.ui:ui"); implementation("androidx.compose.ui:ui-tooling-preview"); implementation("androidx.compose.material3:material3")
 implementation("androidx.room:room-runtime:2.6.1"); implementation("androidx.room:room-ktx:2.6.1"); kapt("androidx.room:room-compiler:2.6.1")
 debugImplementation("androidx.compose.ui:ui-tooling")
}
