package com.goldshop.manager

import android.content.Context
import androidx.room.*

@Entity(tableName="settings")
data class ShopSettings(@PrimaryKey val id:Int=1,val shopName:String="",val address:String="",val phone:String="",val gstin:String="",val state:String="",val invoicePrefix:String="INV",val defaultGst:Double=3.0)
@Entity(tableName="customers",indices=[Index(value=["phone"])])
data class Customer(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val phone:String,val address:String="")
@Entity(tableName="items",indices=[Index(value=["code"],unique=true)])
data class Item(@PrimaryKey(autoGenerate=true) val id:Long=0,val code:String,val description:String,val purity:String,val grossWeight:Double,val stoneWeight:Double=0.0,val makingCharge:Double=0.0,val status:String="IN_STOCK")
@Entity(tableName="transactions",indices=[Index(value=["invoiceNo"],unique=true),Index(value=["customerId"]),Index(value=["itemId"])])
data class Tx(@PrimaryKey(autoGenerate=true) val id:Long=0,val invoiceNo:String,val type:String,val customerId:Long?,val itemId:Long?=null,val gross:Double=0.0,val stone:Double=0.0,val purity:Double=0.0,val fine:Double=0.0,val rate:Double=0.0,val making:Double=0.0,val wastage:Double=0.0,val subtotal:Double=0.0,val cgst:Double=0.0,val sgst:Double=0.0,val igst:Double=0.0,val total:Double=0.0,val paid:Double=0.0,val mode:String="Cash",val status:String="COMPLETED",val createdAt:Long=System.currentTimeMillis())

@Dao interface ShopDao {
 @Query("SELECT * FROM settings WHERE id=1") suspend fun settings():ShopSettings?
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun saveSettings(s:ShopSettings)
 @Query("SELECT * FROM customers ORDER BY name") suspend fun customers():List<Customer>
 @Insert suspend fun addCustomer(c:Customer):Long
 @Query("SELECT * FROM items ORDER BY id DESC") suspend fun items():List<Item>
 @Insert suspend fun addItem(i:Item):Long
 @Query("UPDATE items SET status='SOLD' WHERE id=:id AND status='IN_STOCK'") suspend fun markSold(id:Long):Int
 @Query("UPDATE items SET status='IN_STOCK' WHERE id=:id AND status='SOLD'") suspend fun restoreStock(id:Long):Int
 @Query("SELECT * FROM transactions ORDER BY id DESC") suspend fun txs():List<Tx>
 @Insert suspend fun addTx(t:Tx):Long
 @Query("SELECT * FROM transactions WHERE id=:id LIMIT 1") suspend fun txById(id:Long):Tx?
 @Query("UPDATE transactions SET status='CANCELLED' WHERE id=:id AND status='COMPLETED'") suspend fun cancelTx(id:Long):Int
 @Transaction suspend fun cancel(id:Long):Boolean { val t=txById(id)?:return false; if(t.status!="COMPLETED"||cancelTx(id)!=1)return false; if(t.type=="SALE"&&t.itemId!=null)restoreStock(t.itemId); return true }
}
@Database(entities=[ShopSettings::class,Customer::class,Item::class,Tx::class],version=1,exportSchema=false)
abstract class ShopDb:RoomDatabase(){ abstract fun dao():ShopDao
 companion object { @Volatile private var instance:ShopDb?=null; fun get(c:Context)=instance?:synchronized(this){instance?:Room.databaseBuilder(c.applicationContext,ShopDb::class.java,"gold_shop_fresh.db").build().also{instance=it}} }
}
