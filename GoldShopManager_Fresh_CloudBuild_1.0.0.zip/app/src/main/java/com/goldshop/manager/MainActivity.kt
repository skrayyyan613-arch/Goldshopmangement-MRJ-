package com.goldshop.manager

import android.content.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.content.FileProvider
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}}

fun makeInvoicePdf(ctx:Context,s:ShopSettings,t:Tx,c:Customer?):File{
 val doc=PdfDocument();val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create());val p=page.canvas;val paint=android.graphics.Paint()
 paint.textSize=20f;paint.isFakeBoldText=true;p.drawText(s.shopName.ifBlank{"Gold Shop"},40f,55f,paint)
 paint.textSize=11f;paint.isFakeBoldText=false;p.drawText(s.address,40f,75f,paint);p.drawText("GSTIN: ${s.gstin}   Mobile: ${s.phone}",40f,92f,paint)
 paint.textSize=16f;paint.isFakeBoldText=true;p.drawText("TAX INVOICE",40f,130f,paint)
 paint.textSize=11f;paint.isFakeBoldText=false;p.drawText("Invoice: ${t.invoiceNo}",40f,152f,paint);p.drawText("Customer: ${c?.name?:"Walk-in"}",40f,170f,paint)
 p.drawText("Item weight: %.3f g".format(Locale.US,t.gross),40f,205f,paint)
 p.drawText("Rate: ₹%.2f/g".format(Locale.US,t.rate),40f,222f,paint)
 p.drawText("Making: ₹%.2f".format(Locale.US,t.making),40f,239f,paint)
 p.drawText("Subtotal: ₹%.2f".format(Locale.US,t.subtotal),40f,275f,paint)
 p.drawText("CGST: ₹%.2f".format(Locale.US,t.cgst),40f,292f,paint);p.drawText("SGST: ₹%.2f".format(Locale.US,t.sgst),40f,309f,paint)
 paint.isFakeBoldText=true;paint.textSize=15f;p.drawText("TOTAL: ₹%.2f".format(Locale.US,t.total),40f,345f,paint)
 paint.textSize=11f;paint.isFakeBoldText=false;p.drawText("Paid: ₹%.2f   Due: ₹%.2f   Mode: %s".format(Locale.US,t.paid,(t.total-t.paid).coerceAtLeast(0.0),t.mode),40f,370f,paint)
 p.drawText("This is a prototype invoice preview.",40f,410f,paint)
 doc.finishPage(page);val dir=File(ctx.cacheDir,"invoices");dir.mkdirs();val f=File(dir,"${t.invoiceNo}.pdf");f.outputStream().use{doc.writeTo(it)};doc.close();return f
}
fun shareFile(ctx:Context,f:File){
 val uri=FileProvider.getUriForFile(ctx,"${ctx.packageName}.files",f)
 val send=Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)}
 ctx.startActivity(Intent.createChooser(send,"Share invoice PDF"))
}

@Composable fun App(){
 val ctx=androidx.compose.ui.platform.LocalContext.current;val dao=remember{ShopDb.get(ctx).dao()};val scope=rememberCoroutineScope()
 var page by remember{mutableStateOf("Dashboard")};var s by remember{mutableStateOf(ShopSettings())};var cs by remember{mutableStateOf(emptyList<Customer>())};var items by remember{mutableStateOf(emptyList<Item>())};var txs by remember{mutableStateOf(emptyList<Tx>())}
 var selectedTx by remember{mutableStateOf<Tx?>(null)}
 fun refresh(){scope.launch{s=dao.settings()?:ShopSettings();cs=dao.customers();items=dao.items();txs=dao.txs()}}
 LaunchedEffect(Unit){refresh()}
 val pages=listOf("Dashboard","Invoice","Old Gold","Customers","Stock","Ledger","Settings")
 MaterialTheme{Scaffold(topBar={TopAppBar(title={Text(if(s.shopName.isBlank())"Gold Shop Manager" else s.shopName,fontWeight=FontWeight.Bold)})}){pad->
  Column(Modifier.fillMaxSize().padding(pad)){Box(Modifier.weight(1f)){when(page){
   "Dashboard"->Dashboard(s,cs,items,txs)
   "Invoice"->Invoice(s,cs,items){t->scope.launch{if(t.itemId==null || dao.markSold(t.itemId)==1){try{dao.addTx(t);selectedTx=t}catch(_:Exception){if(t.itemId!=null)dao.restoreStock(t.itemId)}};refresh()}}
   "Old Gold"->OldGold(s,cs){t->scope.launch{dao.addTx(t);selectedTx=t;refresh()}}
   "Customers"->Customers(cs){n,p,a->scope.launch{dao.addCustomer(Customer(name=n,phone=p,address=a));refresh()}}
   "Stock"->Stock(items){i->scope.launch{dao.addItem(i);refresh()}}
   "Ledger"->Ledger(txs,cs,onCancel={id->scope.launch{dao.cancel(id);refresh()}},onPdf={t->selectedTx=t})
   "Settings"->Settings(s){x->scope.launch{dao.saveSettings(x);refresh()}}
  }}
  NavigationBar{Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState())){pages.forEach{p->TextButton(onClick={page=p},modifier=Modifier.padding(horizontal=2.dp)){Text(p,fontSize=12.sp,fontWeight=if(page==p) FontWeight.Bold else FontWeight.Normal)}}}}
  }}
 }
 if(selectedTx!=null){AlertDialog(onDismissRequest={selectedTx=null},title={Text("Invoice Ready")},text={Text("${selectedTx!!.invoiceNo}\nPDF invoice can be generated and shared.")},confirmButton={Button(onClick={val f=makeInvoicePdf(ctx,s,selectedTx!!,cs.firstOrNull{it.id==selectedTx!!.customerId});shareFile(ctx,f);selectedTx=null}){Text("PDF & Share")}},dismissButton={TextButton(onClick={selectedTx=null}){Text("Close")}})}
}
@Composable fun Dashboard(s:ShopSettings,c:List<Customer>,i:List<Item>,t:List<Tx>){val completed=t.filter{it.status=="COMPLETED"};val sales=completed.filter{it.type=="SALE"}.sumOf{it.total};val purchases=completed.filter{it.type=="OLD_GOLD"}.sumOf{it.total};val due=completed.sumOf{(it.total-it.paid).coerceAtLeast(0.0)};val stock=i.filter{it.status=="IN_STOCK"};LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("Dashboard",fontSize=28.sp,fontWeight=FontWeight.Bold);Text("${s.shopName.ifBlank{"Gold Shop Manager"}} • ${s.gstin.ifBlank{"GST not set"})")};item{Stat("Sales","₹%.2f".format(Locale.US,sales))};item{Stat("Old Gold Purchases","₹%.2f".format(Locale.US,purchases))};item{Stat("Outstanding","₹%.2f".format(Locale.US,due))};item{Stat("In Stock","${stock.size} items • %.3f g".format(Locale.US,stock.sumOf{it.grossWeight}))};item{Stat("Customers",c.size.toString())};item{Text("Recent Transactions",fontSize=18.sp,fontWeight=FontWeight.Bold)};items(t.take(5)){x->Text("${x.invoiceNo} • ${x.type} • ₹%.2f • ${x.status}".format(Locale.US,x.total))}}}
@Composable fun Stat(a:String,b:String)=Card(Modifier.fillMaxWidth()){Row(Modifier.fillMaxWidth().padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(a);Text(b,fontWeight=FontWeight.Bold)}}
@Composable fun Settings(s:ShopSettings,save:(ShopSettings)->Unit){var n by remember(s){mutableStateOf(s.shopName)};var a by remember(s){mutableStateOf(s.address)};var p by remember(s){mutableStateOf(s.phone)};var g by remember(s){mutableStateOf(s.gstin)};var st by remember(s){mutableStateOf(s.state)};var pre by remember(s){mutableStateOf(s.invoicePrefix)};var dg by remember(s){mutableStateOf(s.defaultGst.toString())};Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){Text("Shop Settings",fontSize=26.sp,fontWeight=FontWeight.Bold);Field(n,{n=it},"Shop name");Field(a,{a=it},"Address");Field(p,{p=it},"Mobile");Field(g,{g=it},"GSTIN");Field(st,{st=it},"State");Field(pre,{pre=it},"Invoice prefix");Field(dg,{dg=it},"Default GST %");Button(onClick={save(ShopSettings(1,n,a,p,g,st,pre,dg.toDoubleOrNull()?:3.0))}){Text("Save Settings")}}}
@Composable fun Customers(cs:List<Customer>,add:(String,String,String)->Unit){var n by remember{mutableStateOf("")};var p by remember{mutableStateOf("")};var a by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().padding(16.dp)){Text("Customers",fontSize=26.sp,fontWeight=FontWeight.Bold);Field(n,{n=it},"Name");Field(p,{p=it},"Mobile");Field(a,{a=it},"Address");Button(onClick={if(n.isNotBlank()){add(n,p,a);n="";p="";a=""}}){Text("Save Customer")};LazyColumn{items(cs){c->Text("${c.name} • ${c.phone}")}}}}
@Composable fun Stock(is_:List<Item>,add:(Item)->Unit){var code by remember{mutableStateOf("")};var d by remember{mutableStateOf("")};var p by remember{mutableStateOf("22K")};var w by remember{mutableStateOf("")};var st by remember{mutableStateOf("0")};var m by remember{mutableStateOf("0")};Column(Modifier.fillMaxSize().padding(16.dp)){Text("Jewellery Stock",fontSize=26.sp,fontWeight=FontWeight.Bold);Field(code,{code=it},"Item code");Field(d,{d=it},"Description");Field(p,{p=it},"Purity");Field(w,{w=it},"Gross weight g");Field(st,{st=it},"Stone weight g");Field(m,{m=it},"Making ₹");Button(onClick={if(code.isNotBlank()){add(Item(code=code,description=d,purity=p,grossWeight=w.toDoubleOrNull()?:0.0,stoneWeight=st.toDoubleOrNull()?:0.0,makingCharge=m.toDoubleOrNull()?:0.0));code="";d="";w=""}}){Text("Add Item")};LazyColumn{items(is_){x->Text("${x.code} • ${x.description} • ${x.purity} • %.3fg • ${x.status}".format(Locale.US,x.grossWeight))}}}}
@Composable fun Invoice(s:ShopSettings,cs:List<Customer>,is_:List<Item>,save:(Tx)->Unit){var q by remember{mutableStateOf("")};var customerId by remember{mutableStateOf<Long?>(null)};var code by remember{mutableStateOf("")};var rate by remember{mutableStateOf("")};var waste by remember{mutableStateOf("0")};var gst by remember{mutableStateOf(s.defaultGst.toString())};var paid by remember{mutableStateOf("")};var mode by remember{mutableStateOf("Cash")};var out by remember{mutableStateOf("")};val item=is_.firstOrNull{it.code.equals(code,true)&&it.status=="IN_STOCK"};val filtered=cs.filter{q.isBlank()||it.name.contains(q,true)||it.phone.contains(q,true)};LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){item{Text("GST Invoice",fontSize=26.sp,fontWeight=FontWeight.Bold)};item{Field(q,{q=it},"Search customer")};items(filtered.take(5)){c->Button(onClick={customerId=c.id;q=c.name},modifier=Modifier.fillMaxWidth()){Text("${c.name} • ${c.phone}")}};item{Field(code,{code=it},"Item code")};item{Field(rate,{rate=it},"Gold rate / g")};item{Field(waste,{waste=it},"Wastage %")};item{Field(gst,{gst=it},"GST %")};item{Field(mode,{mode=it},"Payment: Cash/UPI/Card/Credit")};item{Field(paid,{paid=it},"Paid amount")};item{if(item!=null)Text("${item.description} • ${item.purity} • ${item.grossWeight} g")};item{Button(onClick={val w=item?.grossWeight?:0.0;val r=rate.toDoubleOrNull()?:0.0;val sub=w*(1+(waste.toDoubleOrNull()?:0.0)/100)*r+(item?.makingCharge?:0.0);val tax=sub*(gst.toDoubleOrNull()?:0.0)/100;out="Subtotal ₹%.2f | CGST ₹%.2f | SGST ₹%.2f | Total ₹%.2f".format(Locale.US,sub,tax/2,tax/2,sub+tax)}){Text("Preview")}};item{Text("Required: select an IN_STOCK item and enter a positive gold rate. Paid cannot exceed total.",fontSize=12.sp)}};item{Text(out,fontWeight=FontWeight.Bold)};item{Button(onClick={
 val w=item?.grossWeight?:0.0;val r=rate.toDoubleOrNull()?:0.0;val wastePct=waste.toDoubleOrNull()?:0.0;val gstPct=gst.toDoubleOrNull()?:0.0;val pay=paid.toDoubleOrNull()?:0.0
 val sub=w*(1+wastePct/100)*r+(item?.makingCharge?:0.0);val tax=sub*gstPct/100;val total=sub+tax
 if(item!=null&&r>0&&wastePct>=0&&gstPct>=0&&pay>=0&&pay<=total){save(Tx(invoiceNo="${s.invoicePrefix}-${System.currentTimeMillis()}",type="SALE",customerId=customerId,itemId=item.id,gross=w,rate=r,making=item.makingCharge,wastage=wastePct,subtotal=sub,cgst=tax/2,sgst=tax/2,total=total,paid=pay,mode=mode))}
}){Text("Save Invoice")}}}}
@Composable fun OldGold(s:ShopSettings,cs:List<Customer>,save:(Tx)->Unit){var q by remember{mutableStateOf("")};var cid by remember{mutableStateOf<Long?>(null)};var g by remember{mutableStateOf("")};var st by remember{mutableStateOf("0")};var p by remember{mutableStateOf("91.67")};var r by remember{mutableStateOf("")};var paid by remember{mutableStateOf("")};var mode by remember{mutableStateOf("Cash")};val filtered=cs.filter{q.isBlank()||it.name.contains(q,true)||it.phone.contains(q,true)};LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){item{Text("Old Gold Purchase",fontSize=26.sp,fontWeight=FontWeight.Bold);Field(q,{q=it},"Search customer")};items(filtered.take(5)){c->TextButton(onClick={cid=c.id;q=c.name},modifier=Modifier.fillMaxWidth()){Text("${c.name} • ${c.phone}")}};item{Field(g,{g=it},"Gross weight g");Field(st,{st=it},"Stone/deduction g");Field(p,{p=it},"Purity %");Field(r,{r=it},"Buy rate / fine g");Field(paid,{paid=it},"Paid");Field(mode,{mode=it},"Payment mode")};item{Button(onClick={val gross=g.toDoubleOrNull()?:0.0;val stone=st.toDoubleOrNull()?:0.0;val pur=p.toDoubleOrNull()?:0.0;val rr=r.toDoubleOrNull()?:0.0;val fine=(gross-stone).coerceAtLeast(0.0)*pur/100;val total=fine*rr;if(cid!=null&&gross>0&&pur>0&&rr>0&&paid.toDoubleOrNull()!=null&&paid.toDouble()<=total)save(Tx(invoiceNo="BUY-${System.currentTimeMillis()}",type="OLD_GOLD",customerId=cid,gross=gross,stone=stone,purity=pur,fine=fine,rate=rr,subtotal=total,total=total,paid=paid.toDouble(),mode=mode))}){Text("Save Purchase")}}}}
@Composable fun Ledger(ts:List<Tx>,cs:List<Customer>,onCancel:(Long)->Unit,onPdf:(Tx)->Unit){var q by remember{mutableStateOf("")};var pendingCancel by remember{mutableStateOf<Tx?>(null)};LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){item{Text("Ledger",fontSize=26.sp,fontWeight=FontWeight.Bold);Field(q,{q=it},"Search")};items(ts.filter{q.isBlank()||it.invoiceNo.contains(q,true)||cs.firstOrNull{c->c.id==it.customerId}?.name?.contains(q,true)==true}){t->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(10.dp)){Text("${t.invoiceNo} • ${t.type}",fontWeight=FontWeight.Bold);Text("₹%.2f • Paid ₹%.2f • Due ₹%.2f • ${t.status}".format(Locale.US,t.total,t.paid,(t.total-t.paid).coerceAtLeast(0.0)));cs.firstOrNull{it.id==t.customerId}?.let{c->Text("Customer: ${c.name} • ${c.phone}")};Row{Button(onClick={onPdf(t)}){Text("PDF")};Spacer(Modifier.width(8.dp));if(t.status=="COMPLETED")TextButton(onClick={pendingCancel=t}){Text("Cancel")}}}}}}}
 if(pendingCancel!=null){AlertDialog(onDismissRequest={pendingCancel=null},title={Text("Cancel transaction?")},text={Text("${pendingCancel!!.invoiceNo} will be marked cancelled. A linked sold item will return to stock." )},confirmButton={Button(onClick={onCancel(pendingCancel!!.id);pendingCancel=null}){Text("Confirm")}},dismissButton={TextButton(onClick={pendingCancel=null}){Text("Keep")}})}}
@Composable fun Field(v:String,on:(String)->Unit,label:String)=OutlinedTextField(v,on,label={Text(label)},modifier=Modifier.fillMaxWidth())
