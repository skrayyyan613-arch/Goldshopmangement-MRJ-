# Gold Shop Manager — Phone Cloud Build

This project includes a GitHub Actions workflow so you can build the APK from an Android phone without installing Android Studio.

## Steps
1. Sign in to GitHub in Chrome.
2. Create a new repository.
3. Upload all files from this project ZIP (keep the `.github/workflows/build-apk.yml` file).
4. Open the repository's **Actions** tab.
5. Select **Build Gold Shop Manager APK** and tap **Run workflow**.
6. Wait for the workflow to finish successfully.
7. Open the completed run and download the **GoldShopManager-debug-apk** artifact.
8. Extract it and install the APK on your phone.

The workflow sets up Java 17, Android SDK 35, and Gradle 8.9 automatically, then builds the debug APK.

For a production release, a private signing keystore should be added later.
